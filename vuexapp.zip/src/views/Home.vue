<template>
  <div class="container">
    <header class="header">首页头部</header>
    <div class="content">
      <BannerList :list="getHomeBannerList"/>
    </div>
  </div>
</template>

<script>
import BannerList from '@/components/BannerList'
import { mapGetters, mapActions } from 'vuex'
import axios from 'axios'
const baseUrl = 'https://www.daxunxun.com'

export default {
  components: {
    BannerList
  },
  computed: {
    ...mapGetters(['getHomeBannerList'])
  },
  mounted () {
    console.log(this.$store)
    this.getHomeBannerListData()
  },
  methods: {
    ...mapActions(['setHomeBannerList']),
    getHomeBannerListData () {
      axios.get(baseUrl + '/banner').then(res => {
        console.log(res)
        let arr = []
        res.data.map(item => {
          arr.push(baseUrl + item)
        })
        this.setHomeBannerList(arr)
        console.log(this.getHomeBannerList)
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>
