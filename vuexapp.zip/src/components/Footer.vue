<template>
  <footer class="footer">
    <ul>
      <router-link to="/home" tag="li">
        <span class="iconfont iconshouye"></span>
        <p>首页</p>
      </router-link>
      <router-link to="/kind" tag="li">
        <span class="iconfont iconclassify_icon"></span>
        <p>详情</p>
      </router-link>
      <router-link to="/cart" tag="li">
        <span class="iconfont icongouwuche"></span>
        <p>购物车</p>
      </router-link>
      <router-link to="/user" tag="li">
        <span class="iconfont iconwode"></span>
        <p>我的</p>
      </router-link>
    </ul>
  </footer>
</template>
