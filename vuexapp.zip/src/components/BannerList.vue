<template>
  <div class="banner">
    <van-swipe :autoplay="3000" indicator-color="white">
      <van-swipe-item
        v-for="(item, index) in list"
        :key="index">
          <img
              :src="item"
            class="banner-item">
        </van-swipe-item>
      <!-- <van-swipe-item>1</van-swipe-item>
      <van-swipe-item>1</van-swipe-item> -->
    </van-swipe>
  </div>
</template>

<script>
import Vue from 'vue'
import { Swipe, SwipeItem } from 'vant'
Vue.use(Swipe).use(SwipeItem)
export default {
  props: {
    list: {
      type: Array,
      default: () => []
    }
  }
}
</script>
<style scoped>
  .banner-item {
    width: 100%;
  }
</style>
