const mutations = {
  SET_HOME_BANNER_LIST (state, arr) {
    state.bannerList = arr
  }
}

export default mutations
