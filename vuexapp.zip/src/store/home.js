// import axios from 'axios'
// const baseUrl = 'https://www.daxunxun.com'
// export default {
//   state: {
//     bannerlist: []
//   },
//   actions: {
//     getHomeBannerList ({ commit }) {
//       axios.get(baseUrl + '/banner').then(res => {
//         let arr = []
//         res.data.map(item => {
//           arr.push(baseUrl + item)
//         })
//         commit('changeHomeBannerList', {
//           data: arr
//         })
//       }).catch(err => {
//         console.log(err)
//       })
//     }
//   },
//   mutations: {
//     changeHomeBannerList (state, payload) {
//       state.bannerlist = payload.data
//       // console.log(state.bannerlist)
//     }
//   }
// }
