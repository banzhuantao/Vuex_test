<template>
  <div class="banner">
    <van-swipe :autoplay="3000" indicator-color="white">
      <van-swipe-item v-for="(item, index) of banner" :key="index">
        <img :src="item" class="banner-item">
      </van-swipe-item>
    </van-swipe>
    <!-- {{ banner }} -->
  </div>
</template>

<script>
import Vue from 'vue'
import { Swipe, SwipeItem } from 'vant'
Vue.use(Swipe).use(SwipeItem)
export default {
  props: {
    banner: {
      type: Array,
      default: () => ['轮播图']
    }
  }
}
</script>
