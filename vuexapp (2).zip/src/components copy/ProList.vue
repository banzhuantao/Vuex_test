<template>
  <div class="prolist">
    <ul>
      <li></li>
    </ul>
  </div>
</template>

<script>
export default {
}
</script>
