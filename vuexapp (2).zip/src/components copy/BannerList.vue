<template>
  <div class="banner">
    <van-swipe :autoplay="3000" indicator-color="white">
      <van-swipe-item v-for="(item, index) of banner" :key="index">
        <img :src="item" class="banner-item">
        <!-- {{ banner }} -->
      </van-swipe-item>
    </van-swipe>
  </div>
</template>

<script>
import Vue from 'vue'
import { Swipe, SwipeItem } from 'vant'
Vue.use(Swipe).use(SwipeItem)
export default {
  props: {
    banner: {
      type: Array,
      default: () => [1, 2, 3, 4]
    }
  }
}
</script>
<style scoped>
  .banner-item {
    width: 100%;
  }
</style>
