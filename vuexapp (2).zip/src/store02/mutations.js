const mutations = {
  SET_HOME_BANNER_LIST (state, homeBannerList) {
    state.bannerList = homeBannerList
  },
  SET_HOME_PRO_LIST (state, homeProList) {
    state.proList = homeProList
  }
}

export default mutations
