const actions = {
  setHomeProList ({ commit }, homeProList) {
    commit('SET_HOME_PRO_LIST', homeProList)
  },
  setHomeBannerList ({ commit }, homeBannerList) {
    commit('SET_HOME_BANNER_LIST', homeBannerList)
  }
}

export default actions
