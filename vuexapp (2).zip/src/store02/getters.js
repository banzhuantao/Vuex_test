const getters = {
  getHomeBannerList (state) {
    return state.bannerList.data
  },
  getHomeProList (state) {
    return state.proList.data
  }
}

export default getters
