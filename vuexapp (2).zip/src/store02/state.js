const state = {
  proList: [],
  bannerList: []
}

export default state
