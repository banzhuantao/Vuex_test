<template>
  <div class="container">
    <header class="header">分类头部</header>
    <div class="content">分类内容</div>
  </div>
</template>

<script>

export default {
}
</script>
