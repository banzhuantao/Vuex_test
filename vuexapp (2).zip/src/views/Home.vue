<template>
  <div class="container">
    <header class="header">首页头部</header>
    <div class="content">
      <BannerList :banner="getHomeBannerList" />
    </div>
  </div>
</template>

<script>
import BannerList from '@/components/BannerList'
import { mapGetters, mapActions } from 'vuex'
import axios from 'axios'

export default {
  data () {
    return {
      baseUrl: 'https://www.daxunxun.com'
    }
  },
  components: {
    BannerList
  },
  computed: {
    ...mapGetters(['getHomeBannerList'])
  },
  mounted () {
    this.getHomeBannerListDate()
  },
  methods: {
    ...mapActions(['setHomeBannerList']),
    getHomeBannerListDate () {
      // console.log(this.baseUrl)
      axios.get(this.baseUrl + '/banner').then(res => {
        console.log(res.data)
        let arr = []
        res.data.map(item => {
          arr.push(this.baseUrl + item)
        })
        this.setHomeBannerList({
          data: arr
        })
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>
