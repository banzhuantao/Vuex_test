<template>
  <div class="container">
    <header class="header">首页头部</header>
    <div class="content">
      <BannerList :banner="getHomeBannerList"/>
      <ProList />
    </div>
  </div>
</template>

<script>
import BannerList from '@/components/BannerList'
import ProList from '@/components/ProList'
import { mapGetters, mapActions } from 'vuex'
import axios from 'axios'

export default {
  data () {
    return {
      baseUrl: 'https://www.daxunxun.com'
    }
  },
  components: {
    BannerList,
    ProList
  },
  computed: {
    ...mapGetters({
      getHomeBannerList: 'getHomeBannerList'
    })
  },
  mounted () {
    this.getHomeBannerListData()
    // console.log(this.$store.getters.getHomeBannerList)
  },
  methods: {
    ...mapActions({
      setHomeBannerList: 'setHomeBannerList'
    }),
    getHomeBannerListData () {
      axios.get(this.baseUrl + '/banner').then(res => {
        // console.log(res.data)
        let arr = []
        res.data.map(item => {
          arr.push(this.baseUrl + item)
        })
        this.setHomeBannerList({
          data: arr
        })
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>
