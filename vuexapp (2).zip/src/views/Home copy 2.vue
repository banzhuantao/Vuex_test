<template>
  <div class="container">
    <header class="header">首页头部</header>
    <div class="content">
      <BannerList :banner="getHomeBannerList"/>
      <ProList :pro="getHomeProList"/>
    </div>
  </div>
</template>

<script>
import BannerList from '@/components/BannerList'
import ProList from '@/components/ProList'
import { mapGetters, mapActions } from 'vuex'
import axios from 'axios'
const baseUrl = 'https://www.daxunxun.com'

export default {
  components: {
    BannerList,
    ProList
  },
  computed: {
    ...mapGetters(['getHomeBannerList', 'getHomeProList'])
  },
  mounted () {
    this.getHomeBannerListData()
    this.getHomeProListData()
    // console.log(this.getHomeBannerList.data)
    // console.log(this.getHomeProList)
    console.log(this.$store)
  },
  methods: {
    ...mapActions(['setHomeBannerList', 'setHomeProList']),
    getHomeBannerListData () {
      axios.get(baseUrl + '/banner').then(res => {
        // console.log(res.data)
        let arr = []
        res.data.map(item => {
          arr.push(baseUrl + item)
        })
        this.setHomeBannerList({
          data: arr
        })
      }).catch(err => {
        console.log(err)
      })
    },
    getHomeProListData () {
      axios.get(baseUrl + '/douban').then(res => {
        // console.log(res.data)
        this.setHomeProList({
          data: res.data
        })
      }).catch(err => {
        console.log(err)
      })
    }
  }
}
</script>
