const mutations = {
  SET_HOME_BANNER_LIST (state, payload) {
    state.bannerList = payload.data
    // console.log(payload.data)
  }
}

export default mutations
