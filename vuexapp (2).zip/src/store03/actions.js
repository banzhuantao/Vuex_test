const actions = {
  setHomeBannerList (state, payload) {
    // console.log(state, payload)
    state.commit('SET_HOME_BANNER_LIST', payload)
  }
}

export default actions
