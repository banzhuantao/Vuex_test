const getters = {
  getHomeBannerList (state) {
    return state.bannerList
  }
}

export default getters
