const actions = {
  setHomeBannerList ({ commit }, arr) {
    commit('SET_HOME_BANNER_LIST', arr)
  }
}

export default actions
