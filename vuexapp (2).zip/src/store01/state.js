const state = {
  bannerList: []
}

export default state
