const getters = {
  getHomeBannerList (state) {
    return state.bannerList.data
  }
}

export default getters
