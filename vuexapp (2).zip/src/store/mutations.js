const mutations = {
  SET_HOME_BANNER_LIST (state, homeBannerList) {
    state.bannerList = homeBannerList
  }
}

export default mutations
