const state = {
  bannerList: [66]
}

export default state
